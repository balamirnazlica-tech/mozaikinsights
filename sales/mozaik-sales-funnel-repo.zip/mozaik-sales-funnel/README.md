# Mozaik Design — Enterprise Sales Funnel

Dashboard and cleaned pipeline data for the Mozaik Design enterprise sales team (Burçin, Zeynep, İrem, Elif), as of 16 April 2026.

## Contents

- **`Enterprise_Sales_Dashboard.html`** — open in any browser. Interactive dashboard with KPIs, funnel charts, rep scoreboard, BOFU close-watch, at-risk deals, data quality audit, and recommendations. Works fully offline.
- **`Enterprise_Sales_Funnel_Clean.xlsx`** — normalized workbook with six sheets (Dashboard, Opportunities, Definitions, Outbound, Data Quality, CRM Schema). All KPIs live as formulas.

## Headline numbers

- 107 open opportunities across TOFU (44), MOFU (30), BOFU (33)
- **€12.87M** gross pipeline · **€6.95M** weighted (Σ value × probability)
- Funnel is **inverted**: 71% of weighted value in BOFU, only 3% in TOFU — Q2 will close strong but Q3+ has a real pipeline hole
- Top 5 BOFU deals carry ~58% of weighted value (concentration risk)
- Data completeness averages 72% across qualification fields; Budget Confirmed is the weakest (66%)

## TOFU / MOFU / BOFU — how we use them here

- **TOFU** — target identified, first contact made, no confirmed brief/budget/timeline. Probability 10–25%.
- **MOFU** — project brief confirmed in €, architect specifying, decision maker known, proposal sent or scheduled. Probability 30–70%.
- **BOFU** — proposal approved, budget explicitly confirmed, compelling event exists, only sign-off/PO/down-payment left. Probability 75–99%.
- **Won / Lost** — missing from the current sheet; the Definitions tab in the XLSX describes how to add them.

Full entry/exit criteria are in the **Definitions** sheet of the XLSX.

## What's missing (key gaps before CRM migration)

- No Won / Lost stages → no win rate, no cycle time
- No stage-entered date → no velocity, no time-in-stage (the Sales Velocity column is 100% empty)
- No lead source or industry tags → can't compare channels or verticals
- 32/107 deals have no numeric € value (stored as text like "teklif verildi")
- ~55% of close dates are missing or free text ("soon", "end of april", "2027")
- Boolean fields mix Turkish/English (evet / yes / hayır / no / belirsiz) — not filterable
- Next Step has no owner and no due date → no cadence

The **CRM Schema** sheet in the XLSX lists the 25 fields to standardize on before migrating to a CRM.

---
Source data: _Enterprise Sales Funnel – Sample Till CRM Adoption.ods_ (not shipped here — this repo contains only the cleaned outputs).
